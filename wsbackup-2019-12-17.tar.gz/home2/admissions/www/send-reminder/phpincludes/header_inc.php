<?php ini_set('error_reporting', 0); ?>
<?php
	include("./phpincludes/session.php");
	include("./phpincludes/connection.php");
	include("./phpincludes/commonfunctions.php");
	include("./phpincludes/GenericClass.php");
	include("./phpincludes/sitePaths.php");
    include("./fckeditor/fckeditor.php");
	include("./phpincludes/class.phpmailer.php");

	
	//$SuperAdminACPerEmailId = "acc1@lifeholidays.in";
?>