<?php 
	//$FCKBasePath = "http://www.buildcorp.co.in/admin/fckeditor/";
	$FCKBasePath = "http://phpclients.dimakhconsultants.com/prime_vastu/pv_admin/fckeditor/";
?>