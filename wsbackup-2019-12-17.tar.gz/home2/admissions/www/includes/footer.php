<footer>
    <span id="year-copy"></span> &copy;<strong><a href="http://www.dimakhconsultants.com/" title="Website design development, Search Engine Optimization, Internet marketing, Web hosting, company in pune India, Web-Flash based designers &amp; consultants in Pune" target="_blank">powered by dimakh consultants</a></strong>
</footer>    