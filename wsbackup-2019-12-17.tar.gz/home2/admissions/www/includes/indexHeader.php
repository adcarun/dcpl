<?php ini_set('error_reporting', 0); ?>
<tr>
	<td>
    	<div class="logoArea">
            <div class="logo">
				<img src="../images/logo.png" style="margin-top:20px;">
            </div>
        </div>
        <div class="mainNav" style="margin:26px 0 0 0;">
            <ol id="toc">
                <li class="current">
                	<a href="./index.php" title="ADMINISTRATIVE LOGIN"><span><img src="images/admin-logo.gif" align="left" style="margin:0 3px;" />Administrative Login</span></a>
                </li>
          	</ol>
        </div>
        
        <div class="breadCrumb" style=""><span>&nbsp;&nbsp;Welcome to Prime Vastu Administrative Panel</span></div>
	</td>
</tr>